</div></div>
<!-- / コンテンツ -->
<div id="footer">
<div class="copyright alphafilter"><p class="align1">Copyright(c) <?php echo date('Y'); ?> <a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a> All Rights Reserved.</p></div>

</div>
<?php wp_footer(); ?></body></html>