  <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar(1) ) : ?>
	<div class="midasi">Sponsored links</div>
  	<div class="pickup4">
	  <div class="pickup4-img">
		<a href="#"><img src="<?php bloginfo('template_directory');?>/images/eye.jpg" alt="*" /></a>
	  </div>
	  <div class="pickup4-inner">
		<p><a href="#">ここに広告分を入れます</a></p>
	  </div>
	</div>
  	<div class="pickup4">
	  <div class="pickup4-img">
		<a href="#"><img src="<?php bloginfo('template_directory');?>/images/eye.jpg" alt="*" /></a>
	  </div>
	  <div class="pickup4-inner">
		<p><a href="#">バナーサイズは180x150px</a></p>
	  </div>
	</div>
  	<div class="pickup4">
	  <div class="pickup4-img">
		<a href="#"><img src="<?php bloginfo('template_directory');?>/images/eye.jpg" alt="*" /></a>
	  </div>
	  <div class="pickup4-inner">
		<p><a href="#">国際基準のバナーサイズ</a></p>
	  </div>
	</div>
  <?php endif; ?>
