(function($){
	$(function(){
		$('#tabs').tabs();
	});
})(jQuery);